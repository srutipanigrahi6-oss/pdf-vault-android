# PDF Vault Android — starter project

This is the first native Android milestone for PDF Vault.

## Included
- Kotlin + Jetpack Compose application shell
- Android Storage Access Framework folder picker
- Persisted user-granted folder permission
- Lists PDF files in the selected folder
- Basic page-by-page PDF reader using Android `PdfRenderer`

## Not included yet
- Nearby device-to-device transfer
- Cloud uploads, accounts, signed links, or revocation
- Recursive browsing of subfolders
- Search, bookmarks, thumbnails, or advanced zoom

## Build requirements
- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3

Open this folder in Android Studio and run the `app` configuration.

## Important storage behavior
The app asks the user to select a folder. Android grants access only to that selected folder and its descendants. The app stores the permission so it can reuse it after restart. It does not scan the entire SD card.

## Package
`com.pdfvault.app`

## Version
1.0.0 (starter)
