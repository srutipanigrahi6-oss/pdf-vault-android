package com.pdfvault.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("pdf_vault", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    VaultHome(
                        initialTree = prefs.getString("tree_uri", null)?.let(Uri::parse),
                        onFolderChosen = { uri ->
                            try {
                                contentResolver.takePersistableUriPermission(
                                    uri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                )
                                prefs.edit().putString("tree_uri", uri.toString()).apply()
                            } catch (_: SecurityException) {
                                // Some providers grant read-only access; retain read permission if available.
                                try {
                                    contentResolver.takePersistableUriPermission(
                                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    )
                                    prefs.edit().putString("tree_uri", uri.toString()).apply()
                                } catch (_: Exception) { }
                            }
                        },
                        onOpenPdf = { uri, name -> openPdf(uri, name) }
                    )
                }
            }
        }
    }

    private fun openPdf(uri: Uri, name: String) {
        val intent = Intent(this, PdfReaderActivity::class.java)
            .putExtra("pdf_uri", uri.toString())
            .putExtra("pdf_name", name)
        startActivity(intent)
    }
}

@Composable
private fun VaultHome(
    initialTree: Uri?,
    onFolderChosen: (Uri) -> Unit,
    onOpenPdf: (Uri, String) -> Unit
) {
    var treeUri by remember { mutableStateOf(initialTree) }
    var pdfs by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var message by remember { mutableStateOf("Choose your PDF_VAULT folder on the SD card to begin.") }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            onFolderChosen(uri)
            treeUri = uri
            message = "Folder connected for future app sessions."
        }
    }

    LaunchedEffect(treeUri) {
        pdfs = withContext(Dispatchers.IO) {
            val folder = treeUri?.let { DocumentFile.fromTreeUri(AppContextHolder.context, it) }
            folder?.let { findPdfs(it) }?.sortedBy { it.name?.lowercase() } ?: emptyList()
        }
        if (treeUri != null && pdfs.isEmpty()) message = "No PDFs found in this selected folder."
    }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("PDF VAULT", style = MaterialTheme.typography.headlineMedium)
        Text("Your documents. Your control.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(16.dp)) {
                Text(if (treeUri == null) "No folder connected" else "Folder permission saved")
                Spacer(Modifier.height(6.dp))
                Text(message, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { folderPicker.launch(treeUri) }) {
                    Text(if (treeUri == null) "Connect SD-card folder" else "Change folder")
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("PDF LIBRARY (${pdfs.size})", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        if (pdfs.isEmpty()) {
            Text("Choose the PDF_VAULT folder itself, or a folder containing PDFs.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pdfs, key = { it.uri.toString() }) { file ->
                    Card(onClick = { file.uri.let { onOpenPdf(it, file.name ?: "Document.pdf") } }) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(file.name ?: "Untitled PDF", style = MaterialTheme.typography.bodyLarge)
                                Text("PDF document", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("OPEN")
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Nearby sharing and online publishing will be added in later milestones.",
            style = MaterialTheme.typography.bodySmall)
    }
}

private fun findPdfs(folder: DocumentFile): List<DocumentFile> {
    val found = mutableListOf<DocumentFile>()
    for (item in folder.listFiles()) {
        if (item.isDirectory) {
            found += findPdfs(item)
        } else if (item.isFile && item.name?.endsWith(".pdf", ignoreCase = true) == true) {
            found += item
        }
    }
    return found
}

// A tiny holder lets the Compose screen resolve DocumentFile without passing an Activity through every layer.
private object AppContextHolder {
    lateinit var context: android.content.Context
}

class PdfReaderActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        val uri = intent.getStringExtra("pdf_uri")?.let(Uri::parse)
        val name = intent.getStringExtra("pdf_name") ?: "PDF"
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (uri == null) Text("Unable to open this document.")
                    else PdfReaderScreen(uri, name, contentResolver)
                }
            }
        }
    }
}

@Composable
private fun PdfReaderScreen(uri: Uri, name: String, resolver: android.content.ContentResolver) {
    var pageIndex by remember(uri) { mutableStateOf(0) }
    var pageCount by remember(uri) { mutableStateOf(0) }
    var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
    var error by remember(uri) { mutableStateOf<String?>(null) }

    LaunchedEffect(uri, pageIndex) {
        val result = withContext(Dispatchers.IO) {
            try {
                val descriptor: ParcelFileDescriptor = resolver.openFileDescriptor(uri, "r")
                    ?: error("Could not open file descriptor")
                descriptor.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        val count = renderer.pageCount
                        if (count == 0) return@withContext Triple(null, 0, "This PDF has no pages.")
                        val safeIndex = pageIndex.coerceIn(0, count - 1)
                        renderer.openPage(safeIndex).use { page ->
                            val scale = minOf(2.0f, 1400f / page.width)
                            val bmp = Bitmap.createBitmap(
                                (page.width * scale).toInt().coerceAtLeast(1),
                                (page.height * scale).toInt().coerceAtLeast(1),
                                Bitmap.Config.ARGB_8888
                            )
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            Triple(bmp, count, null)
                        }
                    }
                }
            } catch (e: Exception) {
                Triple(null, 0, e.message ?: "Could not render this PDF.")
            }
        }
        bitmap = result.first
        pageCount = result.second
        error = result.third
    }

    Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 2)
        Spacer(Modifier.height(8.dp))
        if (error != null) Text(error!!)
        else if (bitmap != null) {
            Image(bitmap!!.asImageBitmap(), contentDescription = "PDF page ${pageIndex + 1}",
                modifier = Modifier.weight(1f).fillMaxWidth())
        } else {
            Text("Loading page…", modifier = Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { if (pageIndex > 0) pageIndex-- }, enabled = pageIndex > 0) {
                Text("Previous")
            }
            Text(if (pageCount == 0) "—" else "${pageIndex + 1} / $pageCount")
            TextButton(onClick = { if (pageIndex + 1 < pageCount) pageIndex++ }, enabled = pageIndex + 1 < pageCount) {
                Text("Next")
            }
        }
    }
}
